# README

Los ejercicios están ordenados por sesión, aunque algunos tienen número erróneo. Para no perderte y entender todo lee **Módulo 2**

https://github.com/danieeeld2/DGIIM/blob/master/Segundo/1%20Cuatrimestre/SO/Pr%C3%A1cticas/Resumen%20Practicas.md