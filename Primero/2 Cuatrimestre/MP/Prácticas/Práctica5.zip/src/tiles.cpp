/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <cassert>
#include "move.h"
#include "movelist.h"
#include "tiles.h"

using namespace std;

Tiles::Tiles() {
    cell = nullptr;
    rows = 0;
    columns = 0;
}

Tiles::Tiles(int r, int c) {
    rows = r;
    columns = c;
    cell = nullptr;
    allocate(r,c);
}

Tiles::Tiles(const Tiles& orig) {
    cell = nullptr;
    copy(orig);
}

Tiles::~Tiles() {
    deallocate();
}


void Tiles::allocate(int r, int c) {
    if (cell != nullptr)
        deallocate();
    
    rows = r;
    columns = c;
    
    cell = new char* [r];
    for (int i = 0; i < r; i++) {
        cell[i] = new char[c];
    }
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            cell[i][j] = EMPTY;
}

void Tiles::deallocate() {
    if(cell != nullptr){
        for(int i = 0; i < getHeight(); i++){
            delete[] cell[i];
        }
        delete[] cell;
    }
}

int Tiles::getHeight() const {
    return rows;
}

int Tiles::getWidth() const {
    return columns;
}

char Tiles::get(int r, int c) const {
    assert(r >= 0 && r < rows);
    assert(c >= 0 && c < columns);
    return cell[r][c];
}

void Tiles::setSize(int r, int c) {
    deallocate();
    assert(r > 0 && c > 0);
    allocate(r,c);
}

void Tiles::set(int r, int c, char l) {
    assert(r >= 0 && r < rows);
    assert(c >= 0 && c < columns);
    cell[r][c] = l;
}

void Tiles::copy(const Tiles& t) {
    char ** aux;
    aux = new char*[t.getHeight()];
    for (int i = 0; i < t.getHeight(); i++){
        aux[i] = new char[t.getWidth()];
    }
    for(int i = 0; i < t.getHeight(); i++){
        for(int j = 0; j < t.getWidth();j++){
            aux[i][j] = t.get(i,j);
        }
    }
    
    deallocate();
    rows = t.getHeight();
    columns = t.getWidth();
    cell = aux;
}

Tiles& Tiles::operator=(const Tiles& orig) {
    if(this != &orig)
        copy(orig);
    return *this;
}

void Tiles::add(const Move& m) {
    if(m.isHorizontal()){
        for(int i = 0; i < m.getLetters().size(); i++){
            if(m.getRow() -1 >= 0 && m.getRow() -1 < rows)
                if(m.getCol() + i -1 >= 0 && m.getCol() + i -1 < columns)
                    set(m.getRow()-1, m.getCol()+i-1, m.getLetters()[i]);
        }
    }else{
        for(int i = 0; i < m.getLetters().size(); i++){
            if(m.getRow() + i -1 >= 0 && m.getRow() + i -1 < rows)
                if(m.getCol() -1 >= 0 && m.getCol() -1 < columns)
                    set(m.getRow()+i -1,m.getCol() -1,m.getLetters()[i]);
        }
    }
}

void Tiles::print(std::ostream& os) const {
    os << rows << " " << columns << endl;
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < columns; j++){
            os << cell[i][j] << " ";
        }
        os << endl;
    }
    os << endl;
}

bool Tiles::read(std::istream& is) {
    is >> rows >> columns;
    
    allocate(rows,columns);
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < columns; j++){
            is >> cell[i][j];
            if(is.eof())
                return false;
        }
    }
    return true;
}

std::istream& operator>>(std::istream& is, Tiles &t){
    t.read(is);
    return is;
}