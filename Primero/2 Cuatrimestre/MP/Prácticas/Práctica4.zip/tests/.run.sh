touch tests//.timeout
CMD="   /home/daniel/Escritorio/DGIIM/Primero/2Cuatrimestre/MP/Movelist/dist/Debug/GNU-Linux/movelist   1> tests//.out11 2>&1"
eval $CMD
rm tests//.timeout
