var searchData=
[
  ['extract',['extract',['../classBag.html#a6a322cd28019d96e9703211bb713aa48',1,'Bag']]]
];
