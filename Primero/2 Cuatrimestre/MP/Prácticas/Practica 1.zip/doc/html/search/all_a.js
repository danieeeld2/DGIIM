var searchData=
[
  ['query',['query',['../classLanguage.html#a54e61d6c3ff6ec45c43e8d577fd91d41',1,'Language']]]
];
