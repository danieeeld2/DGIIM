var searchData=
[
  ['getbackground',['getBackground',['../AnsiTerminal_8h.html#a4b66deb9841f783dbdbc02c8641fe984',1,'AnsiTerminal.h']]],
  ['getblue',['getBlue',['../AnsiTerminal_8h.html#a334e1b2fd6f1a548cf4df7fa3e0c0614',1,'AnsiTerminal.h']]],
  ['getfrequency',['getFrequency',['../classLanguage.html#ac727ac60a054ecd36e526fe93de8fc7f',1,'Language']]],
  ['getgreen',['getGreen',['../AnsiTerminal_8h.html#a77637528826faae2ef33308719d98dd7',1,'AnsiTerminal.h']]],
  ['getlanguage',['getLanguage',['../classLanguage.html#ae601aeb3adba71b80ca3eb25310bed58',1,'Language']]],
  ['getletterset',['getLetterSet',['../classLanguage.html#ad72e0fe4a285a849d217a1b9251c79f1',1,'Language']]],
  ['getred',['getRed',['../AnsiTerminal_8h.html#ae80f2e831b0846d38c3901a009dae8ae',1,'AnsiTerminal.h']]],
  ['getscore',['getScore',['../classLanguage.html#a02f7ca8ab721b358955c50df51de6df1',1,'Language']]],
  ['gettext',['getText',['../AnsiTerminal_8h.html#a807f25b5820cfcad523a7a8cb7aa22fe',1,'AnsiTerminal.h']]]
];
