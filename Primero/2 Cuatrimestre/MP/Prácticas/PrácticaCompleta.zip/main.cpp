/**
 * @file main.cpp
 * @author DECSAI
 * @note To be implemented by students either completely or by giving them
 * key functions prototipes to guide the implementation
 */

#include <string>
#include <cassert>
#include <iostream>
#include <random>
#include <fstream>
#include <cmath>
#include "language.h"
#include "bag.h"
#include "player.h"
#include "move.h"
#include "movelist.h"
#include "tiles.h"
#include "window.h"
#include "AnsiTerminal.h"
using namespace std;


int main(){
    Bag bag;
    Language lang;
    Player player;
    Tiles tiles;
    Move move,aaa;
    Movelist list;
    int a,b;
    int score;
    char auxi;
    
    ifstream file;
    file.open("data/ES_100_156.match");
    string aux;
    
    file >> aux;
    file >> score;
    file >> aux;
    lang.setLanguage(aux);
    file >> a >> b;
    tiles.setSize(a,b);
    for(int i = 0; i < a; i++){
        for(int j = 0; j < b; j++){
            file >> auxi;
            tiles.set(i,j,auxi);
        }
    }
    file >> a >> aux;
    player.add(toISO(aux));
    file >> a >> aux;
    bag.set(toISO(aux));


    while (true) {
        tiles.print(cout);
        cout << endl << player.size() << " " << toUTF(player.to_string());
        cout << endl << bag.size() << " " << toUTF(bag.to_string()) << endl;
        cin >> move;
        list = tiles.findCrosswords(move, lang);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getScore() > 0) {
                tiles.add(list.get(i));
                cout << endl << list.get(i);
            } else {
                cout << "error" << endl << list.get(i) << "          " << list.get(i).getScore();
            }
            //        aaa = tiles.findMaxWord(move.getRow(),move.getCol(),move.isHorizontal());
            //        tiles.add(move);
            //        tiles.print(cout);
            //        cout << endl << aaa;
            cout << endl;
        }
    }
    return 0;
}
