touch tests//.timeout
CMD="valgrind --leak-check=full /home/daniel/Escritorio/MP/Práctica6/dist/Debug/GNU-Linux/practica5  1> tests//.out14 2>&1"
eval $CMD
rm tests//.timeout
