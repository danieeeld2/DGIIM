/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VectorSD.h
 * Author: daniel
 *
 * Created on 25 de abril de 2020, 12:40
 */

#ifndef VECTORSD_H
#define VECTORSD_H
#include <iostream>
#include <fstream>

class VectorSD {
private:
    int * info;
    int util;
    int capacidad;
public:
    VectorSD();
    VectorSD(int n);
    int getDato(int posicion) const;
    int nElementos() const;
    int aniadir (int dato);
    void copia(const VectorSD &vector);
    void liberar();
    void mostrar(std::ostream& flujo) const;
    void leer(std::istream& flujo);
};

#endif /* VECTORSD_H */
