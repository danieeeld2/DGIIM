/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VectorSD.cpp
 * Author: daniel
 * 
 * Created on 25 de abril de 2020, 12:40
 */

#include "VectorSD.h"
#include <iostream>
#include <fstream>

VectorSD::VectorSD() {
    capacidad = 10;
    util = 0;
    if(info != nullptr)
        delete []info;
        
    info = new int[capacidad];
}

VectorSD::VectorSD(int n) {
    capacidad = n;
    util = 0;
    if (info != nullptr)
        delete[]info;

    info = new int[capacidad];
}

int VectorSD::getDato(int posicion) const {
    return info[posicion];
}

int VectorSD::nElementos() const {
    return util;
}

void VectorSD::liberar() {
    if (info != nullptr)
        delete []info;
    info = nullptr;
}


int VectorSD::aniadir(int dato) {
    if(util+1 > capacidad){
        int *aux = new int[util];
        
        for(int i = 0; i != util; i++)
            aux[i] = info[i];
        liberar();
        capacidad = capacidad * 2;
        info = new int[capacidad];
        for(int i = 0; i != util; i++)
            info[i] = aux[i];

        if (aux != nullptr)
            delete []aux;
        aux = nullptr;
    }
    
    util++;
    info[util - 1] = dato;
}

void VectorSD::copia(const VectorSD& vector) {
    liberar();
    info = new int[vector.nElementos()];
    for(int i = 0; i != vector.nElementos(); i++)
        info[i] = vector.getDato(i);
    util = vector.nElementos();
    capacidad = vector.nElementos();
}

void VectorSD::mostrar(std::ostream& flujo) const {
    for(int i = 0; i<util; i++)
        flujo << info[i] << " ";
    flujo << std::endl;
}

void VectorSD::leer(std::istream& flujo) {
    int dato;
    
    while(flujo >> dato){
        aniadir(dato);
    }
}
