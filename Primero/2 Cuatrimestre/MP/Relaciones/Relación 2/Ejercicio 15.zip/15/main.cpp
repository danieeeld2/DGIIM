/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: daniel
 *
 * Created on 25 de abril de 2020, 12:39
 */

#include <iostream>
#include <fstream>
#include "VectorSD.h"
using namespace std;

int main(int argc, char* argv[]){
    VectorSD v;
    if(argc == 1)
        v.leer(cin);
    else{
        ifstream flujo(argv[1]);
        if(!flujo){
            cerr << "Error:Fichero " << argv[1] << "no válido" <<endl;
            return 1;
        }
        v.leer(flujo);
    }
    v.mostrar(cout);
    v.liberar();
}