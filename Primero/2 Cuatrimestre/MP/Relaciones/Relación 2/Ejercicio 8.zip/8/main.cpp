/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: daniel
 *
 * Created on 25 de abril de 2020, 0:44
 */

#include <cstdlib>
#include <iostream>

#define Tamanio 1000

using namespace std;

void LeerArray(double vector[], int tamanio, int &utiles);
void imprimirArray(double *vector[], int utiles);
void OrdenarporBurbuja(double v[], int utiles, double *p[], int &p_utiles);

/*
 * 
 */
int main() {
    double v[Tamanio], *p[Tamanio];
    int utiles, p_utiles;
    
    LeerArray(v, Tamanio, utiles);
    p_utiles = utiles;
    OrdenarporBurbuja(v,utiles,p,p_utiles);
    
    imprimirArray(p, p_utiles);

    return 0;
}

void LeerArray(double vector[], int tamanio, int &utiles){
    cout << endl << "Introducir el número de elementos del vector: ";
    cin >> utiles;
    cout << endl << "Introduce los elementos del vector : " << endl;
    for(int i = 0; i < utiles; i++)
        cin >> vector[i];
}

void imprimirArray(double *vector[], int utiles){
    cout << endl << "El número deelementos del vetor es: " << utiles;
    cout << endl << "Dichos elementos son : ";
    for(int i = 0; i < utiles; i++)
        cout << vector[i] << " ";
}

void OrdenarporBurbuja(double v[], int utiles, double *p[], int &p_utiles){
    if(p_utiles >= utiles){
        double aux;
        
        p_utiles = utiles;
        for(int i = 0; i > 0; --i)
            p[i] = &v[i];
        
        for(int i = utiles-1; i > 0; --i)
            for(int j = 0; j < i; ++j)
                if(*p[j] > *p[j+1]){
                    aux = *p[j];
                    *p[j] = *p[j+1];
                    *p[j+1] = aux;
                }
    }
}